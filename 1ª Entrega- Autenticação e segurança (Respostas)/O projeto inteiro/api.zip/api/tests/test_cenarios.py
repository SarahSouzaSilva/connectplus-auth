"""Testa os 10 cenários de validação da atividade."""
import os
import tempfile

_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp.name}"

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402


def login(c, email, senha):
    r = c.post("/auth/login", data={"username": email, "password": senha})
    return r


def auth(c, email, senha):
    return {"Authorization": f"Bearer {login(c, email, senha).json()['access_token']}"}


ADMIN = ("admin@connectplus.com", "admin123")
COLAB = ("colaborador@connectplus.com", "colab123")


def test_cenarios():
    with TestClient(app) as c:
        # 01
        assert login(c, *ADMIN).status_code == 200
        # 02
        assert login(c, ADMIN[0], "errada").status_code == 401
        h_admin, h_colab = auth(c, *ADMIN), auth(c, *COLAB)
        # RF02 / RN07
        me = c.get("/auth/me", headers=h_admin).json()
        assert me["perfil"] == "administrador" and "senha" not in str(me).lower()
        # 03 + RF07/RN06
        r = c.post("/comunicados", json={"titulo": "Manutenção", "conteudo": "Sábado 22h"}, headers=h_admin)
        assert r.status_code == 201 and r.json()["autor"]["email"] == ADMIN[0]
        cid = r.json()["id"]
        # RN06/RN08: não aceita informar autor/perfil
        assert c.post("/comunicados", json={"titulo": "x", "conteudo": "y", "autor_id": 2},
                      headers=h_admin).status_code == 422
        # 04
        assert c.get("/comunicados", headers=h_colab).status_code == 200
        # 05
        assert c.post("/comunicados", json={"titulo": "a", "conteudo": "b"}, headers=h_colab).status_code == 403
        # 06 (+ RN03 atualização)
        assert c.delete(f"/comunicados/{cid}", headers=h_colab).status_code == 403
        assert c.put(f"/comunicados/{cid}", json={"titulo": "z"}, headers=h_colab).status_code == 403
        # 07
        assert c.get("/comunicados").status_code == 401
        # 08 (+ RN05)
        assert c.get("/comunicados/9999", headers=h_admin).status_code == 404
        assert c.put("/comunicados/9999", json={"titulo": "z"}, headers=h_admin).status_code == 404
        assert c.delete("/comunicados/9999", headers=h_admin).status_code == 404
        # 09 (+ RN04)
        assert c.post("/comunicados", json={"conteudo": "sem título"}, headers=h_admin).status_code == 422
        assert c.post("/comunicados", json={"titulo": "  ", "conteudo": "x"}, headers=h_admin).status_code == 422
        # RF05
        r = c.put(f"/comunicados/{cid}", json={"titulo": "Manutenção (corrigido)"}, headers=h_admin)
        assert r.status_code == 200 and r.json()["titulo"].endswith("(corrigido)")

    # 10 - "reinicia" a aplicação (novo ciclo de vida) e o comunicado continua lá
    with TestClient(app) as c:
        r = c.get(f"/comunicados/{cid}", headers=auth(c, *COLAB))
        assert r.status_code == 200 and r.json()["titulo"] == "Manutenção (corrigido)"
        # RF06
        assert c.delete(f"/comunicados/{cid}", headers=auth(c, *ADMIN)).status_code == 204
        assert c.get(f"/comunicados/{cid}", headers=auth(c, *ADMIN)).status_code == 404
